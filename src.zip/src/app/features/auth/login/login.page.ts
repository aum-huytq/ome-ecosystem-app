import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

type AuthMode = 'login' | 'register';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: false,
})
export class LoginPage implements OnInit {
  mode: AuthMode = 'login';

  loginForm!: FormGroup;
  registerForm!: FormGroup;

  isSubmitting = false;
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router,
  ) {}

  // ================= INIT =================
  ngOnInit(): void {
    this.initForms();
    this.handleOAuthCallback(); // 🔥 BẮT BUỘC
  }

  private initForms(): void {
    this.loginForm = this.fb.group({
      email: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });

    this.registerForm = this.fb.group({
      phone: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required],
    });
  }

  // ================= LOGIN =================
  onLogin(): void {
    if (this.loginForm.invalid) return;

    this.isSubmitting = true;
    this.errorMessage = '';

    const { email, password } = this.loginForm.value;

    this.auth.login(email, password).subscribe({
      next: () => this.router.navigate(['/profile']),
      error: err => {
        this.errorMessage = err?.message || 'Đăng nhập thất bại';
        this.isSubmitting = false;
      },
      complete: () => (this.isSubmitting = false),
    });
  }

  // ================= REGISTER (LOGIC CŨ) =================
  onRegister(): void {
    if (this.registerForm.invalid) return;

    const { phone, password, confirmPassword } = this.registerForm.value;

    if (password !== confirmPassword) {
      this.errorMessage = 'Mật khẩu nhập lại không khớp';
      return;
    }

    this.isSubmitting = true;
    this.errorMessage = '';

    // 🔥 GIỮ NGUYÊN LOGIC CŨ
    this.auth
      .register({
        fullName: phone,
        otp_code: `${phone}@phone.local`,
        password,
      })
      .subscribe({
        next: () => this.router.navigate(['/profile']),
        error: err => {
          this.errorMessage = err?.message || 'Đăng ký thất bại';
          this.isSubmitting = false;
        },
        complete: () => (this.isSubmitting = false),
      });
  }

  // ================= SOCIAL =================
  onLoginWithGoogle(): void {
    this.auth.redirectToOAuth('google');
  }

  onLoginWithFacebook(): void {
    this.auth.redirectToOAuth('facebook');
  }

  onRegisterWithGoogle(): void {
    this.auth.redirectToOAuth('google');
  }

  onRegisterWithFacebook(): void {
    this.auth.redirectToOAuth('facebook');
  }

  // ================= OAUTH CALLBACK =================
  private handleOAuthCallback(): void {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const provider = params.get('state') as 'google' | 'facebook' | null;

    if (!code || !provider) return;

    this.isSubmitting = true;

    this.auth
  .exchangeOAuthCode({
    provider,
    code,
    redirectUri: `${window.location.origin}/auth/login`,
  })
  .subscribe({
    next: () => {
      window.history.replaceState({}, document.title, '/auth/login');
      this.router.navigate(['/profile']);
    },
    error: err => {
      this.errorMessage =
        err?.message || `Đăng nhập bằng ${provider} thất bại`;
      this.isSubmitting = false;
    },
  });

  }

  goToForgotPassword(): void {
    this.router.navigate(['/auth/forgot-password']);
  }
}
