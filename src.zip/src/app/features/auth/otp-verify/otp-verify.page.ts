import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otp-verify',
  templateUrl: './otp-verify.page.html',
  styleUrls: ['./otp-verify.page.scss'],
  standalone: false,
})
export class OtpVerifyPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
