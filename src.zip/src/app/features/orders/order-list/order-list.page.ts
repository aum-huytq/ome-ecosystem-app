import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.page.html',
  styleUrls: ['./order-list.page.scss'],
  standalone: false,
})
export class OrderListPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
