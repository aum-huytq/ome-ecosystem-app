import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addresses',
  templateUrl: './addresses.page.html',
  styleUrls: ['./addresses.page.scss'],
  standalone: false,
})
export class AddressesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
